from abc import ABC


class PaddingABC(ABC):
    small_buff: float
    med_small_buff: float
    med_large_buff: float
    large_buff: float
